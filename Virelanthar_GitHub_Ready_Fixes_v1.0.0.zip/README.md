# Virelanthar — The Living Tongue of Light Remembered

**A constructed language for meaningful speech, songwriting, and cross-language collaboration.**

Virelanthar has a defined grammar, a bilingual English/French lexicon, and a record of historical drafts. Version **1.0.0** is a **newly standardized creative-language edition**: it resolves old contradictions and adds new vocabulary and grammar. It is not presented as an unchanged ancient corpus.

## Start here / Commencer ici

| Resource | English | Français |
|---|---|---|
| [Definitive Standard v1.0.0](Virelanthar%20definitive.MD) | Complete grammar, dictionary, numbers, pronunciation, examples and lessons | Grammaire complète, lexique, nombres et exemples |
| [Zoé's quick start](ChipieVirelanthar.md) | Short bilingual guide and first song handoff | Guide rapide en français, pour la collaboration musicale |
| [Lexicon — CSV](VIRELANTHAR_Definitive_Lexicon_v1.0.0.csv) | Spreadsheet-compatible: 346 headwords | Tableau compatible Excel : 346 entrées |
| [Lexicon — JSON](Lexicon.json) | Structured grammar and lexical data for software | Données structurées pour les outils |
| [Historical source audit](Handoff.md) | Earlier drafts, conflicts, preserved phrases and source notes | Archives, variantes et incertitudes historiques |

## First phrases / Premières phrases

| Virelanthar | English | Français |
|---|---|---|
| `Mi sova.` | I sing. | Je chante. |
| `Ti lith.` | You listen. | Tu écoutes. |
| `Mina so vael un solara.` | We will make a song together. | Nous créerons une chanson ensemble. |
| `Ek’vesh’arun.` | And yet I shine. | Et pourtant, je rayonne. |

## Collaboration

Virelanthar and **Vaeltharyn** are separate creative languages with separate grammar and authorship. Zoé / Zed / SheIsZoe is the creator of Vaeltharyn and an independent collaborator. This repository is designed to help people **understand and respond to Virelanthar**, not to merge or overwrite Vaeltharyn.

## Dictionary formats

- **CSV**: `form,pos,en,fr,category,origin` — opens in spreadsheet software.
- **JSON**: dictionary plus grammar, formulas, and examples — intended for scripts and translation tools.
- **Markdown**: human-readable normative standard and translation notes.

**Translation policy:** do not invent definitions for unknown words; distinguish preserved formulas, newly standardized forms, and archived experimental material. A dictionary alone is not a full automatic translation engine.

## Attribution and reuse

Virelanthar creative direction: **Keth’ar Molishé Nuvah’el**. Standardization and reference package: AI-assisted editorial development. Vaeltharyn remains Zoé's independent work. Public visibility on GitHub does **not** automatically grant a specific open-source license. A license has not yet been selected for this language reference.

**BEST BUILD WINS.**
